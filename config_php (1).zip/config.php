<?php
// بيانات الاتصال بقاعدة البيانات على InfinityFree
$servername = "sql312.infinityfree.com";
$username   = "if0_39710422";
$password   = "3JgCq73PehSkmv4";
$dbname     = "if0_39710422_AndeedHRYemen";

// إنشاء الاتصال
$conn = new mysqli($servername, $username, $password, $dbname);

// فحص الاتصال
if ($conn->connect_error) {
    die("فشل الاتصال بقاعدة البيانات: " . $conn->connect_error);
}

// تحديد ترميز الاتصال إلى UTF-8
$conn->set_charset("utf8");
?>
