window.APP_CONFIG = {
  SITE_NAME: "منصّة التوظيف اليمنية",
  API_BASE_URL: "/api",
  THEME: "light",
  PRIMARY: "#2563eb",
  ACCENT: "#22d3ee"
};