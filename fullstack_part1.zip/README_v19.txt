ارفع هذا المجلد إلى الاستضافة (htdocs). عدّل config.php لبيانات قاعدة البيانات واستورد db/legacy_schema_v14.sql.
